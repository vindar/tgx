Model from Keenan Crane.

https://www.cs.cmu.edu/~kmcrane/Projects/ModelRepository/